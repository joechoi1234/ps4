
qnty=int(input("Please enter quantity of widgets: "))

if(qnty>10000):
  price=10.00
elif(qnty <= 10000 and qnty >= 5000):
  price=20.00
elif(qnty < 5000):
  price=30.00

extprice=qnty * price
tax=extprice * .07
total=extprice + tax

print("Extended price: " , extprice)
print("Tax amount " , tax)
print("Total: " , total)