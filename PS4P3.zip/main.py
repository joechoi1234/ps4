
prince=int(input("Enter a principle amount of a CD: "))
years=int(input("Enter amount of years to maturity: "))

if(prince > 100000 and years == 5):
  intrate=.06
elif((prince <= 100000 and prince >= 50000)and years == 10):
  intrate=.05
elif((prince <= 100000 and prince >= 50000)and years == 5):
  intrate=.04
else:
  intrate=.02

intamnt=prince * intrate

print("Principle: " , prince)
print("Interest rate: " , intrate)
print("Interest amount for first year: " , intamnt)

  