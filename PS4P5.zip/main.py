
lastname=input("Please enter a last name: ")
sal=int(input("Please enter a salary: "))
joblvl=int(input("Please enter a job level: "))

if(joblvl >= 10):
  bonusrte=.25
elif(joblvl <= 9 and joblvl >= 5):
  bonusrte=.2
else:
  bonusrte=.1

bonus=sal * (bonusrte)

print("Last name: " , lastname)
print("Bonus: $" , bonus)