
qnty=int(input("Enter amount of tickets: "))

if(qnty >= 25):
  tix=50.00
elif(qnty <= 24 and qnty >= 10):
  tix=60.00
elif(qnty <= 9 and qnty >= 5):
  tix=70.00
elif(qnty < 5):
  tix=75.00

total=qnty * tix

print("# of tickets: " , qnty)
print("Price per ticket: " , tix)
print("Total: " , total)